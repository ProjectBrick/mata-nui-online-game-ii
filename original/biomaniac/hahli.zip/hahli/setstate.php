<?php
//Originally written by Biomaniac 
//Additions and contributions by Snoopy82, Imold
//Major thanks to Crystal Matrix, jetslandingboard, -Auron-, and Takua Me
//www.bzpower.com


//The really big super function that does the heavy work of variables into a form Flash can understand
  function setupvariable(&$var, $scope=false, $prefix='unique', $suffix='value')
  {
	//This part parses a variable name to figure out what variable the function is dealing with
    if($scope) $vals = $scope;
    else      $vals = $GLOBALS;
    $old = $var;
    $var = $new = $prefix.rand().$suffix;
    $vname = FALSE;
    foreach($vals as $key => $val) {
      if($val === $new) $vname = $key;
    }
    $var = $old;
	$vname = ereg_replace("new", "", $vname );
	//This part opens up the old getstate to get variables that haven't been modified by the current save
	$writefile='getstate.txt';
	$fh=fopen($writefile, 'r');
	$setstateold=file_get_contents($writefile); 
	fclose($fh);
	parse_str($setstateold, $varsold);
	//This part checks to see if a variable has changed or not from the old getstate to the new save. Variables are also put into a Flash-readable form here.
	if($var==""){
		if($varsold[$vname]==""){
			$variablestr="";
		}else{
		$var=$varsold[$vname];
			$variablestr="".$vname."=".$var."&";
		}
		return $variablestr;
	}else{
		$variablestr="".$vname."=".$var."&";
		return $variablestr;
	}
  }
	
//The huge block of variables and variable processing through setupvariable() .
$newAccuracy=$_POST['Accuracy'];
$newAccuracy=setupvariable($newAccuracy);
$newAiyetoroTask=$_POST['AiyetoroTask'];
$newAiyetoroTask=setupvariable($newAiyetoroTask);
$newChampionshipWon=$_POST['ChampionshipWon'];
$newChampionshipWon=setupvariable($newChampionshipWon);
$newcharMackuState=$_POST['charMackuState'];
$newcharMackuState=setupvariable($newcharMackuState);
$newCounterWeight=$_POST['CounterWeight'];
$newCounterWeight=setupvariable($newCounterWeight);
$newDosneTask=$_POST['DosneTask'];
$newDosneTask=setupvariable($newDosneTask);
$newEastBridge=$_POST['EastBridge'];
$newEastBridge=setupvariable($newEastBridge);
$newGakoroProclamation=$_POST['GakoroProclamation'];
$newGakoroProclamation=setupvariable($newGakoroProclamation);
$newHahlisRoof=$_POST['HahlisRoof'];
$newHahlisRoof=setupvariable($newHahlisRoof);
$newItemBambooPole=$_POST['ItemBambooPole'];
$newItemBambooPole=setupvariable($newItemBambooPole);
$newItemBambooWood=$_POST['ItemBambooWood'];
$newItemBambooWood=setupvariable($newItemBambooWood);
$newItemBladder=$_POST['ItemBladder'];
$newItemBladder=setupvariable($newItemBladder);
$newItemCharmAccuracy=$_POST['ItemCharmAccuracy'];
$newItemCharmAccuracy=setupvariable($newItemCharmAccuracy);
$newItemCharmCreation=$_POST['ItemCharmCreation'];
$newItemCharmCreation=setupvariable($newItemCharmCreation);
$newItemCharmCourage=$_POST['ItemCharmCourage'];
$newItemCharmCourage=setupvariable($newItemCharmCourage);
$newItemCharmDuty=$_POST['ItemCharmDuty'];
$newItemCharmDuty=setupvariable($newItemCharmDuty);
$newItemCharmDestiny=$_POST['ItemCharmDestiny'];
$newItemCharmDestiny=setupvariable($newItemCharmDestiny);
$newItemCharmFaith=$_POST['ItemCharmFaith'];
$newItemCharmFaith=setupvariable($newItemCharmFaith);
$newItemCharmPeace=$_POST['ItemCharmPeace'];
$newItemCharmPeace=setupvariable($newItemCharmPeace);
$newItemCharmProsperity=$_POST['ItemCharmProsperity'];
$newItemCharmProsperity=setupvariable($newItemCharmProsperity);
$newItemCharmPurity=$_POST['ItemCharmPurity'];
$newItemCharmPurity=setupvariable($newItemCharmPurity);
$newItemCharmSpeed=$_POST['ItemCharmSpeed'];
$newItemCharmSpeed=setupvariable($newItemCharmSpeed);
$newItemCharmStamina=$_POST['ItemCharmStamina'];
$newItemCharmStamina=setupvariable($newItemCharmStamina);
$newItemCharmStrategy=$_POST['ItemCharmStrategy'];
$newItemCharmStrategy=setupvariable($newItemCharmStrategy);
$newItemCharmStrength=$_POST['ItemCharmStrength'];
$newItemCharmStrength=setupvariable($newItemCharmStrength);
$newItemCharmUnity=$_POST['ItemCharmUnity'];
$newItemCharmUnity=setupvariable($newItemCharmUnity);
$newItemCharmWillpower=$_POST['ItemCharmWillpower'];
$newItemCharmWillpower=setupvariable($newItemCharmWillpower);
$newItemCowrieShell=$_POST['ItemCowrieShell'];
$newItemCowrieShell=setupvariable($newItemCowrieShell);
$newItemCrystalPurity=$_POST['ItemCrystalPurity'];
$newItemCrystalPurity=setupvariable($newItemCrystalPurity);
$newItemCrystalPeace=$_POST['ItemCrystalPeace'];
$newItemCrystalPeace=setupvariable($newItemCrystalPeace);
$newItemCrystalFaith=$_POST['ItemCrystalFaith'];
$newItemCrystalFaith=setupvariable($newItemCrystalFaith);
$newItemCrystalCreation=$_POST['ItemCrystalCreation'];
$newItemCrystalCreation=setupvariable($newItemCrystalCreation);
$newItemCrystalProsperity=$_POST['ItemCrystalProsperity'];
$newItemCrystalProsperity=setupvariable($newItemCrystalProsperity);
$newItemCrystalCourage=$_POST['ItemCrystalCourage'];
$newItemCrystalCourage=setupvariable($newItemCrystalCourage);
$newItemDigger=$_POST['ItemDigger'];
$newItemDigger=setupvariable($newItemDigger);
$newItemDisc=$_POST['ItemDisc'];
$newItemDisc=setupvariable($newItemDisc);
$newItemFishhook=$_POST['ItemFishhook'];
$newItemFishhook=setupvariable($newItemFishhook);
$newItemFishingPole=$_POST['ItemFishingPole'];
$newItemFishingPole=setupvariable($newItemFishingPole);
$newItemFlags=$_POST['ItemFlags'];
$newItemFlags=setupvariable($newItemFlags);
$newItemFlax=$_POST['ItemFlax'];
$newItemFlax=setupvariable($newItemFlax);
$newItemGakoroMap=$_POST['ItemGakoroMap'];
$newItemGakoroMap=setupvariable($newItemGakoroMap);
$newItemHarakekePlants=$_POST['ItemHarakekePlants'];
$newItemHarakekePlants=setupvariable($newItemHarakekePlants);
$newItemHatchet=$_POST['ItemHatchet'];
$newItemHatchet=setupvariable($newItemHatchet);
$newItemKolhiiBall=$_POST['ItemKolhiiBall'];
$newItemKolhiiBall=setupvariable($newItemKolhiiBall);
$newItemKolhiiStick=$_POST['ItemKolhiiStick'];
$newItemKolhiiStick=setupvariable($newItemKolhiiStick);
$newItemLargeShell=$_POST['ItemLargeShell'];
$newItemLargeShell=setupvariable($newItemLargeShell);
$newItemLightstone=$_POST['ItemLightstone'];
$newItemLightstone=setupvariable($newItemLightstone);
$newItemNails=$_POST['ItemNails'];
$newItemNails=setupvariable($newItemNails);
$newItemNet=$_POST['ItemNet'];
$newItemNet=setupvariable($newItemNet);
$newItemNixiesKey=$_POST['ItemNixiesKey'];
$newItemNixiesKey=setupvariable($newItemNixiesKey);
$newItemOre=$_POST['ItemOre'];
$newItemOre=setupvariable($newItemOre);
$newItemPickaxe=$_POST['ItemPickaxe'];
$newItemPickaxe=setupvariable($newItemPickaxe);
$newItemProtodermis=$_POST['ItemProtodermis'];
$newItemProtodermis=setupvariable($newItemProtodermis);
$newItemRigging=$_POST['ItemRigging'];
$newItemRigging=setupvariable($newItemRigging);
$newItemRope=$_POST['ItemRope'];
$newItemRope=setupvariable($newItemRope);
$newItemSailcloth=$_POST['ItemSailcloth'];
$newItemSailcloth=setupvariable($newItemSailcloth);
$newItemSeaweed=$_POST['ItemSeaweed'];
$newItemSeaweed=setupvariable($newItemSeaweed);
$newItemSickle=$_POST['ItemSickle'];
$newItemSickle=setupvariable($newItemSickle);
$newItemSluice=$_POST['ItemSluice'];
$newItemSluice=setupvariable($newItemSluice);
$newItemString=$_POST['ItemString'];
$newItemString=setupvariable($newItemString);
$newKokoroLosses=$_POST['KokoroLosses'];
$newKokoroLosses=setupvariable($newKokoroLosses);
$newKokoroWins=$_POST['KokoroWins'];
$newKokoroWins=setupvariable($newKokoroWins);
$newLastMatch=$_POST['LastMatch'];
$newLastMatch=setupvariable($newLastMatch);
$newLastPlayed=$_POST['LastPlayed'];
$newLastPlayed=setupvariable($newLastPlayed);
$newLekoroLosses=$_POST['LekoroLosses'];
$newLekoroLosses=setupvariable($newLekoroLosses);
$newLekoroWins=$_POST['LekoroWins'];
$newLekoroWins=setupvariable($newLekoroWins);
$newOnukoroLosses=$_POST['OnukoroLosses'];
$newOnukoroLosses=setupvariable($newOnukoroLosses);
$newOnukoroWins=$_POST['OnukoroWins'];
$newOnukoroWins=setupvariable($newOnukoroWins);
$newPokoroLosses=$_POST['PokoroLosses'];
$newPokoroLosses=setupvariable($newPokoroLosses);
$newPokoroWins=$_POST['PokoroWins'];
$newPokoroWins=setupvariable($newPokoroWins);
$newpreviousScene=$_POST['previousScene'];
$newpreviousScene=setupvariable($newpreviousScene);
$newscene=$_POST['scene'];
$newscene=setupvariable($newscene);
$newSpeed=$_POST['Speed'];
$newSpeed=setupvariable($newSpeed);
$newStamina=$_POST['Stamina'];
$newStamina=setupvariable($newStamina);
$newStrategy=$_POST['Strategy'];
$newStrategy=setupvariable($newStrategy);
$newStrength=$_POST['Strength'];
$newStrength=setupvariable($newStrength);
$newTakoroDestroyed=$_POST['TakoroDestroyed'];
$newTakoroDestroyed=setupvariable($newTakoroDestroyed);
$newTakoroLosses=$_POST['TakoroLosses'];
$newTakoroLosses=setupvariable($newTakoroLosses);
$newTakoroWins=$_POST['TakoroWins'];
$newTakoroWins=setupvariable($newTakoroWins);
$newversion=$_POST['version'];
$newversion=setupvariable($newversion);
$newWaterWheel=$_POST['WaterWheel'];
$newWaterWheel=setupvariable($newWaterWheel);
$newWidgets=$_POST['Widgets'];
$newWidgets=setupvariable($newWidgets);
$newWillpower=$_POST['Willpower'];
$newWillpower=setupvariable($newWillpower);

//This block assembles all variables into a string that flash loads
$savestate="".$newAccuracy."".$newAiyetoroTask."".$newChampionshipWon."".$newcharMackuState."".$newCounterWeight."".$newDosneTask."".$newEastBridge."".$newGakoroProclamation."".$newHahlisRoof."".$newItemBambooPole."".$newItemBambooWood."".$newItemBladder."".$newItemCharmAccuracy."".$newItemCharmCreation."".$newItemCharmCourage."".$newItemCharmDuty."".$newItemCharmDestiny."".$newItemCharmFaith."".$newItemCharmFaith."".$newItemCharmPeace."".$newItemCharmProsperity."".$newItemCharmPurity."".$newItemCharmSpeed."".$newItemCharmStamina."".$newItemCharmStrategy."".$newItemCharmStrength."".$newItemCharmUnity."".$newItemCharmWillpower."".$newItemCowrieShell."".$newItemCrystalPurity."".$newItemCrystalPeace."".$newItemCrystalFaith."".$newItemCrystalCreation."".$newItemCrystalProsperity."".$newItemCrystalCourage."".$newItemDigger."".$newItemDisc."".$newItemFishhook."".$newItemFishingPole."".$newItemFlags."".$newItemFlax."".$newItemGakoroMap."".$newItemHarakekePlants."".$newItemHatchet."".$newItemKolhiiBall."".$newItemKolhiiStick."".$newItemLargeShell."".$newItemLightstone."".$newItemNails."".$newItemNet."".$newItemNixiesKey."".$newItemOre."".$newItemPickaxe."".$newItemProtodermis."".$newItemRigging."".$newItemRope."".$newItemSailcloth."".$newItemSeaweed."".$newItemSickle."".$newItemSluice."".$newItemString."".$newKokoroLosses."".$newKokoroWins."".$newLastMatch."".$newLastPlayed."".$newLekoroLosses."".$newLekoroWins."".$newOnukoroLosses."".$newOnukoroWins."".$newPokoroLosses."".$newPokoroWins."".$newpreviousScene."".$newscene."".$newSpeed."".$newStamina."".$newStrategy."".$newStrength."".$newTakoroDestroyed."".$newTaKoroLosses."".$newTaKoroWins."".$newversion."".$newWaterWheel."".$newWidgets."".$newWillpower."";


//Here, that big string above is written to the getstate.
$writefile='getstate.txt';
$fh=fopen($writefile, 'w');
fwrite($fh, $savestate); 
fclose($fh);

?>