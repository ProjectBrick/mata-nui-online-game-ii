=============================================================
                 Mata Nui Online Game II
=============================================================
At the moment, this is a version of the MNOG II that works
easily offline. Open player.htm in your web browser to play
the game.

To save the game, you would use getplayer.asp. Alter the file
with a program like Notepad. It starts you off with every
item and in Hahli's Hut. To start from the beginning, erase
everything in the file. If you want to start from a different
scene, alter the file and change the line: "scene=HahlisHut"

Change the 'HahlisHut' part to any file in this folder to
appear there. For example, if you wanted to start the game
off at the Le-Koro Town Square, change the line to
"scene=LekoroTownSquare". If you have any questions, consult
the Bionicle software forum of BZPower.com.